// React 页面代码将用户个性化首页展示在此（简化）
export default function HomePage() {
  return <div className='text-white bg-black min-h-screen flex items-center justify-center'>Hello, this is your personal site!</div>;
}